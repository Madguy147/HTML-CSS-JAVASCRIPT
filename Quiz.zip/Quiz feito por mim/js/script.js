document.getElementsByClassName(red)
document.getElementsByClassName(blue)
document.getElementsByClassName(green)
document.getElementsByClassName(yellow)

