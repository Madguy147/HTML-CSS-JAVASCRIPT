import java.util.ArrayList;

//1.Elabore um programa que receba uma lista de inteiros e adicione os números de 1 a 10. Em seguida, percorra a lista e imprima cada elemento multiplicado por 2.

public class Ex12 {

    public static void main(String[] args) { 

        ArrayList<Integer> numeros = new ArrayList<>();

        for(int i = 0; i < 10; i++){
            numeros.add((1 + i) * 2);
        }

        
            System.out.println("Lista de números: " + numeros);

    }
}
