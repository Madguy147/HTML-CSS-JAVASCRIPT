
import java.util.*;

//2.Crie um programa que leia 5 nomes do teclado e os armazene em um ArrayList. Depois, imprima todos os nomes em ordem inversa.

public class Ex13 {

    public static void main(String[] args) {

        Scanner ler = new Scanner(System.in);

        List<String> nomes = new ArrayList<>();

        for (int i = 0; i < 5; i++) {

            System.out.println("Diga os nomes!: ");
            nomes.add(ler.nextLine());
        }

        Collections.reverse(nomes);

        for (String nome : nomes) {
            System.out.println("Os nomes são: " + nome);
        }
        ler.close();
    }
}
