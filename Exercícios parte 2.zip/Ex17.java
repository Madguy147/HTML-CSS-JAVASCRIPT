import java.util.*;

//6.Elabore um programa que adicione 10 números aleatórios (entre 1 e 100) em um ArrayList. Em seguida, ordene os números em ordem crescente e imprima o resultado.

public class Ex17 {
    public static void main(String[] args) {
        List<Integer> numeros = new ArrayList<>();
        Random rand = new Random();

        for (int i = 0; i < 10; i++) {
            numeros.add(rand.nextInt(100) + 1);
        }

        Collections.sort(numeros);
        System.out.println("Números ordenados: " + numeros);
    }
}