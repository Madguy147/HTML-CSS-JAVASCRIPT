import java.util.ArrayList;

public class Ex07 {

    public static void main(String[] args) { 

        ArrayList<String> carros = new ArrayList<String>();

        carros.add("Fusca");
        carros.add("BYD");
        carros.add("BMW");
        carros.add("Fiat");
        carros.add("Volkswagen");

        System.out.println(carros);
    }
}
