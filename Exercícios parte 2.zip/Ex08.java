import java.util.ArrayList;
import java.util.Arrays;

public class Ex08 {

    public static void main(String[] args) { 

        String[] diciplinas = {"matematica", "filosofia", "história", "fisíca"};
        ArrayList<String> novaLista = new ArrayList<String>(Arrays.asList(diciplinas));
        novaLista.add("geografia");
        novaLista.add("língua inglesa");

        for(String i: novaLista){
            System.out.println("Disciplina: " + i);
        }
    }
}
