import java.util.ArrayList;

public class Ex11 {

    public static void main(String[] args) { 

        ArrayList<Integer> numeros = new ArrayList<>();

        for(int i = 0; i < 10; i++){
            numeros.add(1 + i);
        }

        numeros.remove(3);

        System.out.println("Lista: " + numeros);
    }
}
