import java.util.*;

//4.Implemente um programa que armazene notas de alunos em um ArrayList de Double. Depois, calcule e exiba a média das notas e quantas notas estão acima da média.

public class Ex15 {

    public static void main(String[] args) { 

        Scanner ler = new Scanner(System.in);

        double notas[] = new double [5];

        
        for(int i = 0; i < 5; i++){
            System.out.println("Diga as notas: ");
            notas [i] = ler.nextDouble();
        }

        double soma = 0;

        for (double nota : notas){
            soma =+ nota * notas.length;

        }
        
        double media = soma / notas.length;

        System.out.println("A média dos alunos foi: " + media);

        for(double nota : notas){

            if(nota < 7){
                System.out.println("A nota: " + nota + " foi abaixo da média");
            }else{
                System.out.println("A nota: " + nota + " foi acima da média");
            }
        }

        ler.close();
    }
}
