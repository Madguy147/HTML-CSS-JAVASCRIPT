import java.util.*;

//9.Faça um programa que leia 10 palavras do usuário e armazene em um ArrayList. Em seguida, remova todas as palavras que possuam menos de 4 letras.

public class Ex20 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<String> palavras = new ArrayList<>();

        for (int i = 0; i < 10; i++) {
            System.out.print("Palavra: ");
            palavras.add(sc.nextLine());
        }

        palavras.removeIf(p -> p.length() < 4);

        System.out.println("Palavras com 4 ou mais letras:");
        for (String p : palavras) {
            System.out.println(p);
        }
    }
}