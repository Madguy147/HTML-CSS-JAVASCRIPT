import java.util.Scanner;

public class Ex02 {

    public static void main(String[] args) {
        try (Scanner ler = new Scanner(System.in)) {

            int a;
            int b;
            int c;

            System.out.print("Informe o primeiro valor: ");
            a = ler.nextInt();

            System.out.print("Informe o segundo valor: ");
            b = ler.nextInt();
            
            System.out.print("Informe o terceiro valor: ");
            c = ler.nextInt();

            if(a > b && a > c){
                System.out.println("O primeiro número é o maior!");
            }else if(b > a && b > c){
                System.out.println("O segundo número é o maior!");
            }else{
                if (a == c || c == b){
                    System.out.println("Dois ou mais números são iguais!");
                }else{
                    System.out.println("O terceiro número é o maior!");
                }
            }
        }
    }
}
