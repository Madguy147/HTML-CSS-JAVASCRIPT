import java.util.Scanner;

public class Ex03 {

    public static void main(String[] args) { 

        Scanner ler = new Scanner(System.in);

        System.out.print("Escolha de 1 a 3: ");
        int numero = ler.nextInt();

        switch (numero){
            case 1:
            System.out.println("Você escolheu 1");
            break;
            case 2:
            System.out.println("Você escolheu 2");
            break;
            case 3:
            System.out.println("Você escolheu 3");
            break;
            default:
            System.out.println("Você escolheu outro número!!!");
        }
    }
}
