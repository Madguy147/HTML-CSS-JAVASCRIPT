import java.util.*;

//5.Crie um programa que leia uma frase do usuário e armazene cada palavra em um ArrayList. Depois, imprima quantas palavras a frase possui e quais começam com a letra "A".

public class Ex16 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite uma frase: ");
        String frase = sc.nextLine();
        String[] palavras = frase.split("\\s+");

        List<String> listaPalavras = Arrays.asList(palavras);
        System.out.println("Total de palavras: " + listaPalavras.size());

        System.out.println("Palavras que começam com 'A':");
        for (String palavra : listaPalavras) {
            if (palavra.toUpperCase().startsWith("A")) {
                System.out.println(palavra);
            }
        }
    }
}