import java.util.*;

//3.Escreva um programa que preencha um ArrayList com os 20 primeiros números pares. Em seguida, remova todos os elementos divisíveis por 4.

public class Ex14 {

    public static void main(String[] args) { 

        List<Integer> pares = new ArrayList<>();

        for(int i = 2; pares.size() < 20; i += 2){
            pares.add(i);
        }

        pares.removeIf(n -> n % 4 > 0 || n % 4 < 0 );

        for(int n : pares){
            System.out.println(n);
        }
    }
}
